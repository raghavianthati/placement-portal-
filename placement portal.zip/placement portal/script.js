```javascript
// Home Page Button
function showMessage() {
    alert("Welcome to the Placement Preparation Portal!");
}

// Feature Buttons
function showTopic(topic) {
    alert("Opening " + topic + " Module");
}

// Mock Test Buttons
function startTest(test) {
    alert("Starting " + test);
}

// Login Form
const loginForm = document.getElementById("loginForm");

if (loginForm) {
    loginForm.addEventListener("submit", function(e) {
        e.preventDefault();

        const email = document.getElementById("loginEmail").value;
        const password = document.getElementById("loginPassword").value;

        if(email === "" || password === "") {
            alert("Please fill all fields.");
            return;
        }

        alert("Login Successful!");
        window.location.href = "index.html";
    });
}

// Register Form
const registerForm = document.getElementById("registerForm");

if(registerForm){

registerForm.addEventListener("submit",function(e){

e.preventDefault();

const password=document.getElementById("password").value;
const confirm=document.getElementById("confirmPassword").value;

if(password!==confirm){

alert("Passwords do not match.");

return;

}

alert("Registration Successful!");

window.location.href="login.html";

});

}

// Contact Form
const contactForm=document.getElementById("contactForm");

if(contactForm){

contactForm.addEventListener("submit",function(e){

e.preventDefault();

alert("Thank you! Your message has been sent.");

contactForm.reset();

});

}
```
